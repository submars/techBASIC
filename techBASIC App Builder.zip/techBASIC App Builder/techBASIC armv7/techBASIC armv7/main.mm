//
//  main.m
//  techBASIC armv7
//
//  Created by Mike Westerfield on 11/19/12.
//  Copyright (c) 2012 Byte Works. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
