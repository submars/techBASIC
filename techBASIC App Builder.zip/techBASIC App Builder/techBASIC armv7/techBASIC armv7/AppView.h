//
//  AppView.h
//  techBASIC_for_App_Store
//
//  Created by Mike Westerfield on 11/16/12.
//  Copyright (c) 2012 Mike Westerfield. All rights reserved.
//

#import <UIKit/UIKit.h>

#include "AppStoreGraphicsView.h"

@interface AppView : AppStoreGraphicsView

@end
